/*8.Viết chương trình cho phép người dùng nhập vào một chuỗi s bất kì với các yêu cầu sau:
a.	Nếu chuỗi s là rỗng thì hiển thị “invalid”. Ngược lại thực hiện yêu cầu tiếp theo.
b.	Chương trình hiển thị menu các lựa chọn như sau:
--------------------------------
#1 – So luong ky tu trong chuoi
#2 – In hoa tat ca cac ky tu
#3 – In thuong tat ca cac ky tu
#4 – Thoat
--------------------------------
c.	Nếu người dùng nhập vào số 1, chương trình hiển thị số lượng ký tự có trong chuỗi s. Sau đó, chương trình tiếp tục hiển thị lại menu đến khi người dùng chọn “Thoat”.
d.	Nếu người dùng nhập vào số 2, chương trình sẽ thực hiện in hoa toàn bộ ký tự trong chuỗi s và hiển thị chuỗi s ra màn hình. Sau đó, chương trình tiếp tục hiển thị lại menu đến khi người dùng chọn “Thoat”.
e.	Nếu người dùng nhập vào số 3, chương trình sẽ thực hiện in thường toàn bộ ký tự trong chuỗi s và hiển thị chuỗi s ra màn hình. Sau đó, chương trình tiếp tục hiển thị lại menu đến khi người dùng chọn “Thoat”.
f.	Nếu người dùng nhập vào số 4, thực hiện thoát chương trình. (Gợi ý: Thoát khỏi vòng lặp). 

 */

package FUNCTIONS_2;

import java.util.Scanner;

public class Ex8 {

	public static void main(String[] args) {
		while (true) {
			String s = getInput();
			int choose = choose();
			process(choose, s);
		}

	}

	static Scanner sc = new Scanner(System.in);

	static String getInput() {
		while (true) {
			System.out.println("Enter a chain: ");
			String s = sc.nextLine();
			if (s == "") {
				System.out.println("Invalid");
			} else {
				return s;
			}
		}
	}

	static void menu() {
		System.out.println("----------------------");
		System.out.println("#1 So Luong Ki Tu Trong Chuoi");
		System.out.println("#2 In Hoa Tat Ca Cac Ky Tu");
		System.out.println("#3 In Thuong Tat Ca Cac Ky Tu");
		System.out.println("#4 Thoat");
		System.out.println("----------------------");
	}

	static int choose() {
		while (true) {
			menu();
			int choose = sc.nextInt();
			if (choose > 0 && choose < 5)
				return choose;
		}
	}

	static void printNumberOfChar(String s) {
		int count = 0;
		for (int i = 0; i < s.length(); i++) {
			count++;
		}
		System.out.println("The number of character in this chain is: " + count);
	}

	static void Upper(String s) {
		String upper = s.toUpperCase();
		System.out.println("The chain after upper case is: " + upper);
	}

	static void Lower(String s) {
		String lower = s.toLowerCase();
		System.out.println("The chain after lower case is: " + lower);
	}

	static void process(int choose, String s) {
		switch (choose) {
		case 1:
			printNumberOfChar(s);
			break;
		case 2:
			Upper(s);
			break;
		case 3:
			Lower(s);
			break;
		default:
			System.exit(0);
			break;
		}

	}
}
